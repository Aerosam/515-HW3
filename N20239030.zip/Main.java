//Hessam Farhat, N20239030, hessamfarhat@hacettepe.edu.tr

/*
 * Contacts.txt input dosyasinda kisi bilgilerini okuyup ve java Collection siniflarini
 * kullanarak cesitli veri yapilarinda saklanacaktir, ardindan asagidaki talimati izleyerek
 * farkli bir dosya yazdiracaktir:
 * 1-kisileri bir ArrayList'e aktarip, ardindan kisileri ArrayList'i kullanarak degerleri
 * ContactsArrayList.txt dosyasina yaziyor.
 * 
 * 2- kisileri soyadina gore siralamak icin Comparator uygulayan Class LastNameComparator
 * sinifini olusturuyor. ArrayList'i Collection.sort kullanarak siralamak icin LastNameComparator
 * sinifini kullan. Ardindan kisileri, ContactsArrayListOrderByLastName.txt dosyasina yaziyor.
 * 
 * 3-kisileri bir hashSet'e aktariyor, ardindan kisileri HashSet'i kullanarak ContactsHashSet.txt
 * dosyasina yaziyor.
 * 
 * 4-kisileri bir TreeSet'e aktariyor, ardindan kisileri TreeSet'i kullanarakContactsTreeSet.txt
 * dosyasina yaziyor.
 * 
 * 5-kisileri TreeSet ile soyad sirasina gore saklamak icin LastNameComparator sinifini kullaniyor,
 * ardindan kisileri, ContactsTreeSetOrderByLastName.txt dosyasina yaziyor.
 * 
 * 6-kisileri key olarak bir telefon numarasini ve value olarak bir Contact nesnesini kullanarak
 * bir HashMap'te depoluyor. ardindan, HashMap'i kullanarak kisileri ContactsHashMap.txt
 * dosyasina yaziyor. 
 */
package homework3;

import java.util.*;
import java.io.*;


public class Main {

	public static void main(String[] args) {
		String contact = args[0];
		String ContactsArrayList = "ContactsArrayList.txt";
		String ContactsHashSet = "ContactsHashSet.txt";
		String ContactsHashMap = "ContactsHashMap.txt";
		String ContactsTreeSetOrderByLastName = "ContactsTreeSetOrderByLastName.txt";
		String ContactsTreeSet = "ContactsTreeSet.txt";
		String ContactsArrayListOrderByLastName = "ContactsArrayListOrderByLastName.txt";
		
		Comparator<Contact> comp1 = Comparator.comparing(Contact::getLastName);
		Comparator<Contact> comp2 = Comparator.comparing(Contact::getPhoneNumber);
		
		HashSet<Contact> hash = new HashSet<Contact>();
		TreeSet<Contact> tree = new TreeSet<Contact>();
		HashMap<String, Contact> hshmp = new HashMap<String, Contact>();
		TreeSet<Contact> tri = new TreeSet<Contact>(comp2);
		ArrayList<Contact> cont1 = new ArrayList<Contact>();
		
		
		
		try {
			BufferedReader bfr = new BufferedReader(new FileReader(contact));
			String fec = null;
			while((fec = bfr.readLine()) != null) {
				String kisim[] = fec.split(" ");
				Contact cont2 = new Contact(kisim[0], kisim[1], kisim[2], kisim[3]);
				cont1.add(cont2);
				hash.add(cont2);
				tri.add(cont2);
				tree.add(cont2);
				hshmp.put(kisim[0], cont2);
			}
			bfr.close();
			
			BufferedWriter bfr1 = new BufferedWriter(new FileWriter(ContactsArrayList));
			for (Contact x : cont1) {
				bfr1.write(x.toString());
				bfr1.newLine();
			}
			bfr1.close();
			
			Collections.sort (cont1, comp1);
			BufferedWriter bfr2 = new BufferedWriter(new FileWriter(ContactsArrayListOrderByLastName));
			for (Contact x : cont1) {
				bfr2.write(x.toString());
				bfr2.newLine();
			}
			bfr2.close();
			
			BufferedWriter bfr3 = new BufferedWriter(new FileWriter(ContactsHashSet));
			for (Contact y : hash) {
				bfr3.write(y.getPhoneNumber() + " " + y.getFirstName() + " " + y.getLastName() + " " + y.getSocialSecurityNumber());
				bfr3.newLine();
			}
			bfr3.close();
			
			BufferedWriter bfr4 = new BufferedWriter(new FileWriter(ContactsTreeSet));
			Iterator<Contact> iter = tri.iterator();
			while (iter.hasNext()) {
				bfr4.write(iter.next().toString());
				bfr4.newLine();
			}
			bfr4.close();
			
			BufferedWriter bfr5 = new BufferedWriter(new FileWriter(ContactsTreeSetOrderByLastName));
			Iterator<Contact> iter2 = tree.iterator();
			while (iter2.hasNext()) {
				bfr5.write(iter2.next().toString());
				bfr5.newLine();
			}
			bfr5.close();
			
			BufferedWriter bfr6 = new BufferedWriter(new FileWriter(ContactsHashMap));
			for (Map.Entry<String, Contact> entry : hshmp.entrySet()) {
				bfr6.write(entry.getValue().toString());
				bfr6.newLine();
			}
			bfr6.close();
		

	}
		catch(Exception ex) {
			return;
		}

	}
}
