//Hessam Farhat, N20239030, hessamfarhat@hacettepe.edu.tr
/*
 * her veri yapisi asagidaki 4 String turune ait degiskene sahip Contact sinifinin bir nesnesi
 * olarak tutuyor.
 */
package homework3;

public class Contact implements Comparable<Contact> {
	
	private String socialSecurityNumber;
	private String firstName;
	private String lastName;
	private String phoneNumber;
	
	
	
	public Contact(String phoneNumber, String firstName, String lastName, String socialSecurityNumber) {
		this.phoneNumber = phoneNumber;
		this.firstName = firstName;
		this.lastName = lastName;
		this.socialSecurityNumber = socialSecurityNumber;
	}
	
	
	public String getFirstName() {
		return firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public String getPhoneNumber() {
		return phoneNumber;
	}

	public String getSocialSecurityNumber() {
		return socialSecurityNumber;
	}
	
	@Override 
	public String toString() {
		return String.format("%s %s %s %s", phoneNumber, firstName, lastName, socialSecurityNumber);
	}
	
	@Override 
	public int compareTo(Contact o) {
		return getLastName().compareTo(((Contact) o).getLastName());
	}

}
